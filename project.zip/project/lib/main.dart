import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.content.Intent
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

// Mixin for CommonActivity
interface CommonActivity {
fun navigateTo(activity: AppCompatActivity, targetClass: Class<*>) {
val intent = Intent(activity, targetClass)
activity.startActivity(intent)
}
}

// MainActivity.kt
class MainActivity : AppCompatActivity(), CommonActivity {
override fun onCreate(savedInstanceState: Bundle?) {
super.onCreate(savedInstanceState)
setContentView(R.layout.activity_main)

val usernameField: EditText = findViewById(R.id.usernameField)
val passwordField: EditText = findViewById(R.id.passwordField)
val loginButton: Button = findViewById(R.id.loginButton)

loginButton.setOnClickListener {
navigateTo(this, DashboardActivity::class.java)
}
}
}

// DashboardActivity.kt
class DashboardActivity : AppCompatActivity(), CommonActivity {
override fun onCreate(savedInstanceState: Bundle?) {
super.onCreate(savedInstanceState)
setContentView(R.layout.activity_dashboard)

val rides = listOf(
Ride("Morning Ride", "9:00 AM", "₹200"),
Ride("Evening Ride", "5:00 PM", "₹300")
)

val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
recyclerView.layoutManager = LinearLayoutManager(this)
recyclerView.adapter = RideAdapter(rides) { ride ->
val intent = Intent(this, RideDetailsActivity::class.java)
intent.putExtra("rideName", ride.name)
intent.putExtra("rideTime", ride.time)
intent.putExtra("rideCost", ride.cost)
startActivity(intent)
}
}
}

// RideDetailsActivity.kt
class RideDetailsActivity : AppCompatActivity(), CommonActivity {


override fun onCreate(savedInstanceState: Bundle?) {
super.onCreate(savedInstanceState)
setContentView(R.layout.activity_ride_details)

val rideName = intent.getStringExtra("rideName")
val rideTime = intent.getStringExtra("rideTime")
val rideCost = intent.getStringExtra("rideCost")

val nameTextView: TextView = findViewById(R.id.nameTextView)
val timeTextView: TextView = findViewById(R.id.timeTextView)
val costTextView: TextView = findViewById(R.id.costTextView)

nameTextView.text = "Name: $rideName"
timeTextView.text = "Time: $rideTime"
costTextView.text = "Cost: $rideCost"
}
}

// Ride.kt
data class Ride(val name: String, val time: String, val cost: String)

// RideAdapter.kt
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class RideAdapter(
private val rides: List<Ride>,
private val onRideClick: (Ride) -> Unit
) : RecyclerView.Adapter<RideAdapter.RideViewHolder>() {

override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RideViewHolder {
val view = LayoutInflater.from(parent.context).inflate(R.layout.ride_item, parent, false)
return RideViewHolder(view)
}

override fun onBindViewHolder(holder: RideViewHolder, position: Int) {
val ride = rides[position]
holder.bind(ride, onRideClick)
}

override fun getItemCount(): Int = rides.size

class RideViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
private val nameTextView: TextView = itemView.findViewById(R.id.nameTextView)
private val timeTextView: TextView = itemView.findViewById(R.id.timeTextView)

fun bind(ride: Ride, onRideClick: (Ride) -> Unit) {
nameTextView.text = ride.name
timeTextView.text = "Time: ${ride.time}"
itemView.setOnClickListener { onRideClick(ride) }
}
}
}